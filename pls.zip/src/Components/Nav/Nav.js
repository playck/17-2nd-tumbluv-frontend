import React from 'react';

const Nav = () => {
  return <div></div>;
};

export default Nav;
