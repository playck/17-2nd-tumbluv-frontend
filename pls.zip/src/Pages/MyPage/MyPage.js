import React from 'react';

const MyPage = () => {
  return <div></div>;
};

export default MyPage;
