import React from 'react';

const ProjectUpload = () => {
  return <div></div>;
};

export default ProjectUpload;
