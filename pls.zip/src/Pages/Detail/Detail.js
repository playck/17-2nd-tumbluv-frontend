import React from 'react';

const Detail = () => {
  return <div></div>;
};

export default Detail;
